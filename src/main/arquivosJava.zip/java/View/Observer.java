package View;

public interface Observer {
    public void update();
}
